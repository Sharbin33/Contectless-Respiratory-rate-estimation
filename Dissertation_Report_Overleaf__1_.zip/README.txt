DISSERTATION PHASE - 1 (MTCS382) REPORT - LaTeX TEMPLATE
M.Tech. Computer Science and Engineering

HOW TO USE
1. Fill in your details in Generics/ProjectVariables.tex
   (student name, register number, title, guide, co-guide, His/Her, dates).
   If you have no co-guide, change \HasCoGuidetrue to \HasCoGuidefalse.
2. Write your chapters in the Chapters folder, and your appendix in Appendices/AppendixA.tex.
3. Put figures in the Figures folder and add references to Bibliography.bib (minimum 15).
   Copy the example blocks to add figures and tables - they are listed automatically in the
   List of Figures and the List of Tables:
   - Chapter 1: example figure and example table
   - Chapter 2: example Literature Review table that continues on the next page if it is long
   Delete the examples (and Figures/SampleFigure.png) once you add your own.
4. Before submitting, change \ShowPageGuidelinestrue to \ShowPageGuidelinesfalse
   in Generics/ProjectVariables.tex to hide the "[This chapter should be ... pages long.]" notes.

HOW TO COMPILE
Main file: ProjectReport.tex
- Overleaf: upload this zip as a new project. pdfLaTeX works as it is; set the compiler
  to XeLaTeX (Menu > Compiler) if you want the real Times New Roman font.
- Local: pdflatex ProjectReport -> bibtex ProjectReport -> pdflatex ProjectReport -> pdflatex ProjectReport
  (or: latexmk -pdf ProjectReport)

REPORT GUIDELINES (already set up in the template, applied from the chapters onwards;
the pages before the chapters keep the normal template margins)
Font                  - Times New Roman
Size                  - Title of the chapter - 16, Sub heading - 14, Sub-sub heading - 12, Complete text - 12
Line spacing          - 1.5
Alignment             - Justify
Margin                - Left - 1.75 in, Right - 0.75 in, Top - 1 in, Bottom - 1 in
No. of pages          - Introduction - 3-5, Literature Survey - 5-10, Problem Formulation - 2-3,
                        Methodology - 5-6, Design and Implementation - 5-6, Results and Discussion - 5-8
References            - Minimum 15 count
Total number of pages - 30 pages, excluding the pages numbered in roman numerals and the appendices
