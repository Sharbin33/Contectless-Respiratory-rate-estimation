Place your figures (.png, .jpg, .pdf, .eps) in this folder and include them with \includegraphics{filename}.
SampleFigure.png is only a placeholder used by the example figure in Chapter 1 - delete it once you add your own figures.
